<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="20592" tilewidth="5" tileheight="5" tilecount="62376" columns="678">
 <image source="20592.png" width="3392" height="460"/>
</tileset>
