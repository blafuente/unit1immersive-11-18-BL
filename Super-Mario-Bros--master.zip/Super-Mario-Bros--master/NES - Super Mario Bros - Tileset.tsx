<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="NES - Super Mario Bros - Tileset" tilewidth="100" tileheight="100" tilecount="20" columns="5">
 <image source="../../../../Downloads/NES - Super Mario Bros - Tileset.png" width="528" height="448"/>
</tileset>
