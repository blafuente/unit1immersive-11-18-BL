<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="NES - Super Mario Bros - World 1-1_01" tilewidth="100" tileheight="100" tilecount="288" columns="72">
 <image source="NES - Super Mario Bros - World 1-1_01.png" width="7257" height="480"/>
</tileset>
