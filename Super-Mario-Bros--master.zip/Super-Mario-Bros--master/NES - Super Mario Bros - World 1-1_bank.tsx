<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="NES - Super Mario Bros - World 1-1_bank" tilewidth="32" tileheight="32" tilecount="40" columns="5">
 <image source="../../../../Desktop/sprites/NES - Super Mario Bros - World 1-1_bank.png" width="176" height="272"/>
</tileset>
