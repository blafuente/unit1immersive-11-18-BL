class Enemy(Sprite):
    def __init__(self):
        